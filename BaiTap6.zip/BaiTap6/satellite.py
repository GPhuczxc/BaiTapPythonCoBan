import numpy as np
import cv2
import os
import skfuzzy as fuzz
from sklearn.cluster import KMeans
from sklearn.metrics import f1_score, adjusted_rand_score
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Bước 1: Tải ảnh từ thư mục
def load_images_from_folder(folder_path):
    images = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".jpg"):
            img_path = os.path.join(folder_path, filename)
            img = cv2.imread(img_path)
            if img is not None:
                images.append(img)
    return images

# Bước 2: Xử lý ảnh
def preprocess_images(images):
    features = []
    for img in images:
        # Chuyển đổi kích thước ảnh và làm phẳng
        img_resized = cv2.resize(img, (64, 64))
        img_flattened = img_resized.flatten()
        features.append(img_flattened)
    features = np.array(features)
    return StandardScaler().fit_transform(features)  # Chuẩn hóa dữ liệu

# Bước 3: Áp dụng K-means clustering
def kmeans_clustering(features, n_clusters=3):
    kmeans = KMeans(n_clusters=n_clusters, random_state=0)
    kmeans.fit(features)
    return kmeans.labels_

# Bước 4: Áp dụng Fuzzy C-means clustering
def fcm_clustering(features, n_clusters=3):
    cntr, u, _, _, _, _, _ = fuzz.cluster.cmeans(
        data=features.T, c=n_clusters, m=2, error=0.005, maxiter=1000)
    fcm_labels = np.argmax(u, axis=0)
    return fcm_labels

# Bước 5: Đánh giá phân cụm bằng F1-score và RAND Index
def evaluate_clustering(true_labels, predicted_labels):
    f1 = f1_score(true_labels, predicted_labels, average='weighted')
    rand_index = adjusted_rand_score(true_labels, predicted_labels)
    return f1, rand_index

# Đường dẫn đến thư mục ảnh
folder_path = "C:/Users/ADMIN/PycharmProjects/AnhVaThiGiacMayTinh/BaiTap6/Picture"
images = load_images_from_folder(folder_path)
features = preprocess_images(images)

# Kiểm tra số lượng ảnh để tạo nhãn
num_images = len(images)
print("Số lượng ảnh:", num_images)

# Chạy phân cụm K-means và FCM
kmeans_labels = kmeans_clustering(features)
fcm_labels = fcm_clustering(features)

# Tạo nhãn thực tế giả

true_labels = np.random.randint(0, 3, num_images)

# Đánh giá kết quả
kmeans_f1, kmeans_rand = evaluate_clustering(true_labels, kmeans_labels)
fcm_f1, fcm_rand = evaluate_clustering(true_labels, fcm_labels)

print("Đánh giá K-means:")
print("F1-score:", kmeans_f1)
print("RAND Index:", kmeans_rand)

print("\nĐánh giá Fuzzy C-means (FCM):")
print("F1-score:", fcm_f1)
print("RAND Index:", fcm_rand)

# Bước 6: Hiển thị kết quả bằng cách sử dụng PCA để giảm số chiều
pca = PCA(n_components=2)
features_2d = pca.fit_transform(features)

plt.figure(figsize=(12, 5))

# Hiển thị K-means
plt.subplot(1, 2, 1)
plt.scatter(features_2d[:, 0], features_2d[:, 1], c=kmeans_labels, cmap='viridis')
plt.title("Phân cụm K-means")

# Hiển thị FCM
plt.subplot(1, 2, 2)
plt.scatter(features_2d[:, 0], features_2d[:, 1], c=fcm_labels, cmap='viridis')
plt.title("Phân cụm Fuzzy C-means (FCM)")

plt.show()
