
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
import skfuzzy as fuzz
import matplotlib.pyplot as plt
from sklearn.metrics import f1_score, adjusted_rand_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import pairwise_distances_argmin_min

# Bước 1: Tải dữ liệu IRIS
def load_iris_data(file_path):
    columns = ["sepal_length", "sepal_width", "petal_length", "petal_width", "species"]
    data = pd.read_csv(file_path, header=None, names=columns)
    features = data.iloc[:, :-1].values
    labels = LabelEncoder().fit_transform(data.iloc[:, -1].values)
    return features, labels

features, labels = load_iris_data("iris.data")

# Bước 2: Phân cụm K-means
def kmeans_clustering(features, n_clusters=3):
    kmeans = KMeans(n_clusters=n_clusters, random_state=0)
    kmeans.fit(features)
    return kmeans.labels_

kmeans_labels = kmeans_clustering(features)

# Bước 3: Phân cụm Fuzzy C-means (FCM)
def fcm_clustering(features, n_clusters=3):
    cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
        data=features.T, c=n_clusters, m=2, error=0.005, maxiter=1000, init=None)
    fcm_labels = np.argmax(u, axis=0)
    return fcm_labels

fcm_labels = fcm_clustering(features)

# Bước 4: Đánh giá bằng F1-score và RAND Index
def evaluate_clustering(true_labels, predicted_labels):
    f1 = f1_score(true_labels, predicted_labels, average='weighted')
    rand_index = adjusted_rand_score(true_labels, predicted_labels)
    return f1, rand_index

kmeans_f1, kmeans_rand = evaluate_clustering(labels, kmeans_labels)
fcm_f1, fcm_rand = evaluate_clustering(labels, fcm_labels)

print("K-means Evaluation:")
print("F1-score:", kmeans_f1)
print("RAND Index:", kmeans_rand)

print("\nFuzzy C-means (FCM) Evaluation:")
print("F1-score:", fcm_f1)
print("RAND Index:", fcm_rand)

# Bước 5: Hiển thị kết quả
plt.figure(figsize=(12, 5))

# Hiển thị K-means
plt.subplot(1, 2, 1)
plt.scatter(features[:, 0], features[:, 1], c=kmeans_labels, cmap='viridis')
plt.title("K-means Clustering")

# Hiển thị FCM
plt.subplot(1, 2, 2)
plt.scatter(features[:, 0], features[:, 1], c=fcm_labels, cmap='viridis')
plt.title("Fuzzy C-means (FCM) Clustering")

plt.show()
