import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
from typing import Tuple, List


DATASET_DIR = "./Picture"
IMAGE_SIZE = (64, 64)


class SVMClassifier:
    def __init__(self, kernel: str = 'linear', C: float = 1.0):
        """
        Khởi tạo SVM với kernel và hệ số C.

        Args:
            kernel (str): Kernel sử dụng cho SVM ('linear', 'poly', 'rbf', 'sigmoid').
            C (float): Hệ số điều chỉnh, càng cao thì càng chú trọng vào độ chính xác.
        """
        self.kernel = kernel
        self.C = C
        self.model = SVC(kernel=kernel, C=C)

    def load_data(self) -> Tuple[np.ndarray, np.ndarray]:
        """Load dataset from the specified directory."""
        labels = []
        images = []
        for category in os.listdir(DATASET_DIR):
            category_path = os.path.join(DATASET_DIR, category)
            if os.path.isdir(category_path):
                for image_name in os.listdir(category_path):
                    image_path = os.path.join(category_path, image_name)
                    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
                    if image is not None:
                        image = cv2.resize(image, IMAGE_SIZE)  # Resize ảnh
                        images.append(image.flatten())  # Chuyển thành vector 1 chiều
                        labels.append(category)
                    else:
                        print(f"Warning: Unable to read image {image_path}")
        return np.array(images), np.array(labels)

    def train(self, X_train: np.ndarray, y_train: np.ndarray):
        """Train the SVM model."""
        self.model.fit(X_train, y_train)

    def predict(self, X_test: np.ndarray) -> np.ndarray:
        """Predict labels for the test set."""
        return self.model.predict(X_test)

    def evaluate(self, y_true: np.ndarray, y_pred: np.ndarray):
        """Print evaluation metrics and plot confusion matrix."""
        print("Classification Report:")
        print(classification_report(y_true, y_pred))
        print("\nConfusion Matrix:")
        cm = confusion_matrix(y_true, y_pred)
        print(cm)
        print("\nAccuracy Score:", accuracy_score(y_true, y_pred))
        self.plot_confusion_matrix(cm, sorted(set(y_true)))

    @staticmethod
    def plot_confusion_matrix(cm: np.ndarray, classes: List[str]):
        """Plot confusion matrix for visualization."""
        plt.figure(figsize=(10, 7))
        plt.imshow(cm, interpolation='nearest', cmap='Blues')
        plt.title("Confusion Matrix")
        plt.colorbar()
        tick_marks = np.arange(len(classes))
        plt.xticks(tick_marks, classes, rotation=45)
        plt.yticks(tick_marks, classes)

        # Ghi số vào từng ô của confusion matrix
        for i in range(len(classes)):
            for j in range(len(classes)):
                plt.text(j, i, format(cm[i, j], 'd'),
                         horizontalalignment="center",
                         color="white" if cm[i, j] > cm.max() / 2. else "black")

        plt.xlabel("Predicted Label")
        plt.ylabel("True Label")
        plt.tight_layout()
        plt.show()

    def run(self):
        """Execute the entire pipeline: load data, train, test, and evaluate."""
        print("Loading data...")
        X, y = self.load_data()

        if X.size == 0 or y.size == 0:
            print("Error: No data found. Please check the dataset path and structure.")
            return

        # Tách dữ liệu thành tập huấn luyện và tập kiểm tra
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        print("Training the SVM model...")
        self.train(X_train, y_train)

        print("Predicting the test set...")
        y_pred = self.predict(X_test)

        print("Evaluating the model...")
        self.evaluate(y_test, y_pred)


if __name__ == "__main__":
    # Khởi tạo và chạy class với kernel mặc định là 'linear'
    svm_classifier = SVMClassifier(kernel='linear', C=1.0)
    svm_classifier.run()
