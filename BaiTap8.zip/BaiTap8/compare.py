import matplotlib.pyplot as plt
import numpy as np
from KNN import KNNClassifier
from SVM import SVMClassifier
from ANN import ANNClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

DATASET_DIR = "./Picture"
IMAGE_SIZE = (64, 64)


class CompareClassifiers:
    def __init__(self):
        # Khởi tạo các mô hình với tham số mặc định
        self.knn = KNNClassifier(n_neighbors=5)
        self.svm = SVMClassifier(kernel='linear', C=1.0)
        self.ann = ANNClassifier(hidden_layer_sizes=(128, 64), max_iter=200)

        # Biến để lưu trữ kết quả của các mô hình
        self.results = {}
        self.y_test = None  # Khởi tạo thuộc tính y_test

    def load_data(self):
        """Load và chuẩn bị dữ liệu."""
        X, y = self.knn.load_data()  # Load từ KNN vì cấu trúc load giống nhau
        if X.size == 0 or y.size == 0:
            raise ValueError("Error: No data found. Please check the dataset path and structure.")
        return train_test_split(X, y, test_size=0.3, random_state=42)

    def train_and_evaluate(self, model, X_train, y_train, X_test, y_test, model_name):
        """Huấn luyện và đánh giá một mô hình."""
        model.train(X_train, y_train)
        y_pred = model.predict(X_test)

        accuracy = accuracy_score(y_test, y_pred)
        cm = confusion_matrix(y_test, y_pred)
        report = classification_report(y_test, y_pred, output_dict=True)

        self.results[model_name] = {
            "accuracy": accuracy,
            "confusion_matrix": cm,
            "classification_report": report
        }

        print(f"\n{model_name.upper()} Accuracy: {accuracy:.2f}")
        print(f"{model_name.upper()} Classification Report:\n", classification_report(y_test, y_pred))
        print(f"{model_name.upper()} Confusion Matrix:\n", cm)

    def plot_results(self):
        """Vẽ biểu đồ để so sánh độ chính xác và hiển thị ma trận nhầm lẫn."""
        # Biểu đồ so sánh độ chính xác và F1-score
        accuracies = [self.results[model]["accuracy"] for model in self.results]
        f1_scores = [self.results[model]["classification_report"]['accuracy'] for model in self.results]
        model_names = list(self.results.keys())

        plt.figure(figsize=(14, 6))

        # Biểu đồ độ chính xác
        plt.subplot(1, 2, 1)
        plt.bar(model_names, accuracies, color=['blue', 'green', 'red'])
        plt.title("Accuracy Comparison")
        plt.xlabel("Model")
        plt.ylabel("Accuracy")

        # Biểu đồ F1-score
        plt.subplot(1, 2, 2)
        plt.bar(model_names, f1_scores, color=['blue', 'green', 'red'])
        plt.title("F1-Score Comparison")
        plt.xlabel("Model")
        plt.ylabel("F1-Score")

        plt.tight_layout()
        plt.show()

        # Biểu đồ ma trận nhầm lẫn
        classes = sorted(set(self.y_test))  # Dùng self.y_test
        plt.figure(figsize=(12, 8))
        for idx, model_name in enumerate(model_names):
            plt.subplot(2, 3, idx + 1)
            cm = self.results[model_name]["confusion_matrix"]
            plt.imshow(cm, interpolation='nearest', cmap='Blues')
            plt.title(f"{model_name.upper()} Confusion Matrix")
            plt.colorbar()
            plt.xlabel("Predicted Label")
            plt.ylabel("True Label")

            tick_marks = np.arange(len(classes))
            plt.xticks(tick_marks, classes, rotation=45)
            plt.yticks(tick_marks, classes)

            for i in range(len(classes)):
                for j in range(len(classes)):
                    plt.text(j, i, format(cm[i, j], 'd'),
                             horizontalalignment="center",
                             color="white" if cm[i, j] > cm.max() / 2. else "black")

        plt.tight_layout()
        plt.show()

    def run_comparison(self):
        """Thực thi toàn bộ quy trình so sánh."""
        print("Loading and splitting data...")
        X_train, X_test, y_train, self.y_test = self.load_data()  # Gán y_test cho self.y_test

        # Huấn luyện và đánh giá từng mô hình
        print("\nTraining and evaluating KNN model...")
        self.train_and_evaluate(self.knn, X_train, y_train, X_test, self.y_test, "knn")

        print("\nTraining and evaluating SVM model...")
        self.train_and_evaluate(self.svm, X_train, y_train, X_test, self.y_test, "svm")

        print("\nTraining and evaluating ANN model...")
        self.train_and_evaluate(self.ann, X_train, y_train, X_test, self.y_test, "ann")

        # Vẽ kết quả
        self.plot_results()


if __name__ == "__main__":
    comparator = CompareClassifiers()
    comparator.run_comparison()
