import tkinter as tk
from tkinter import filedialog, Label, Frame
from PIL import Image, ImageTk
import cv2
import numpy as np
from sklearn.mixture import GaussianMixture

class EMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Phân nhóm Expectation Maximization với phân đoạn ảnh")
        self.root.geometry("710x700")
        self.root.configure(bg="#F5F5F5")

        self.image_path = None
        self.processed_image = None


        self.create_widgets()

    def create_widgets(self):

        control_frame = Frame(self.root, bg="#e0e0e0", pady=10)
        control_frame.pack(fill=tk.X)

        # Nút chọn ảnh
        select_image_button = tk.Button(control_frame, text="Chọn Ảnh", command=self.select_image, font=("Arial", 12), bg="#4CAF50", fg="white", relief="raised", bd=2)
        select_image_button.pack(side=tk.LEFT, padx=10, pady=10)

        # Nút áp dụng từng toán tử
        tk.Button(control_frame, text="Áp dụng Sobel", command=self.apply_sobel, font=("Arial", 12), bg="#2196F3", fg="white", relief="raised", bd=2).pack(side=tk.LEFT, padx=10)
        tk.Button(control_frame, text="Áp dụng Canny", command=self.apply_canny, font=("Arial", 12), bg="#FF9800", fg="white", relief="raised", bd=2).pack(side=tk.LEFT, padx=10)
        tk.Button(control_frame, text="Áp dụng Gaussian", command=self.apply_gaussian, font=("Arial", 12), bg="#9C27B0", fg="white", relief="raised", bd=2).pack(side=tk.LEFT, padx=10)

        # Nút áp dụng Expectation Maximization
        tk.Button(control_frame, text="Áp dụng EM", command=self.apply_em, font=("Arial", 12), bg="#f44336", fg="white", relief="raised", bd=2).pack(side=tk.LEFT, padx=10)

        # Hiển thị ảnh gốc
        self.original_label = Label(self.root, text="Ảnh gốc", font=("Arial", 14), bg="#F5F5F5")
        self.original_label.pack(pady=5)
        self.original_canvas = tk.Label(self.root, bg="white", relief="solid", bd=1)
        self.original_canvas.pack(pady=10)

        # Hiển thị ảnh đã xử lý
        self.processed_label = Label(self.root, text="Ảnh đã xử lý", font=("Arial", 14), bg="#F5F5F5")
        self.processed_label.pack(pady=5)
        self.processed_canvas = tk.Label(self.root, bg="white", relief="solid", bd=1)
        self.processed_canvas.pack(pady=10)

    def select_image(self):
        self.image_path = filedialog.askopenfilename(initialdir="C:/Users/ADMIN/PycharmProjects/AnhVaThiGiacMayTinh/BaiTap7/Picture", title="Chọn ảnh vệ tinh",
                                                     filetypes=(("jpg files", "*.jpg"), ("all files", "*.*")))
        if self.image_path:
            self.display_image(self.image_path, self.original_canvas)

    def display_image(self, img_path, canvas):
        img = Image.open(img_path).resize((330, 280), Image.LANCZOS)
        img = ImageTk.PhotoImage(img)
        canvas.configure(image=img)
        canvas.image = img

    def apply_sobel(self):
        if not self.image_path:
            return
        img = cv2.imread(self.image_path, cv2.IMREAD_GRAYSCALE)
        sobel = cv2.Sobel(img, cv2.CV_64F, 1, 1, ksize=5)
        sobel = cv2.convertScaleAbs(sobel)
        _, sobel = cv2.threshold(sobel, 50, 255, cv2.THRESH_BINARY)  # Ngưỡng hóa để giữ lại cạnh mạnh
        self.display_processed_image(sobel)

    def apply_canny(self):
        if not self.image_path:
            return
        img = cv2.imread(self.image_path, cv2.IMREAD_GRAYSCALE)
        blurred = cv2.GaussianBlur(img, (5, 5), 1.4)  # Làm mờ ảnh để giảm nhiễu
        canny = cv2.Canny(blurred, 50, 150)  # Ngưỡng điều chỉnh có thể thay đổi
        self.display_processed_image(canny)

    def apply_gaussian(self):
        if not self.image_path:
            return
        img = cv2.imread(self.image_path)
        gaussian = cv2.GaussianBlur(img, (15, 15), 0)  # Thử nghiệm với kích thước kernel lớn hơn để giảm nhiễu
        self.display_processed_image(gaussian)

    def apply_em(self):
        if not self.image_path:
            return
        img = cv2.imread(self.image_path)
        pixel_values = img.reshape((-1, 3)).astype(np.float32)

        # Sử dụng thuật toán Gaussian Mixture  để phân nhóm
        gmm = GaussianMixture(n_components=5, covariance_type='full', random_state=0)
        gmm.fit(pixel_values)
        labels = gmm.predict(pixel_values)
        centers = gmm.means_


        segmented_image = centers[labels].reshape(img.shape)
        segmented_image = np.uint8(segmented_image)  # Chuyển đổi về dạng uint8 để hiển thị

        self.display_processed_image(segmented_image)

    def display_processed_image(self, processed_img):
        img = Image.fromarray(np.uint8(processed_img)).resize((330, 280), Image.LANCZOS)
        img = ImageTk.PhotoImage(img)
        self.processed_canvas.configure(image=img)
        self.processed_canvas.image = img

if __name__ == "__main__":
    root = tk.Tk()
    app = EMApp(root)
    root.mainloop()
